package com.gvent.app.data.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.gvent.app.data.model.AppUser
import com.gvent.app.domain.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class FirebaseAuthRepository : AuthRepository {

    private val auth: FirebaseAuth = Firebase.auth

    private val _currentUser = MutableStateFlow<AppUser?>(firebaseUserToAppUser(auth.currentUser))

    override val currentUser: StateFlow<AppUser?>
        get() {
            val user = auth.currentUser
            if (user != null && _currentUser.value == null) {
                _currentUser.value = firebaseUserToAppUser(user)
            }
            return _currentUser.asStateFlow()
        }

    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        _currentUser.value = firebaseUserToAppUser(firebaseAuth.currentUser)
    }

    init {
        auth.addAuthStateListener(authStateListener)
    }

    private fun firebaseUserToAppUser(user: FirebaseUser?): AppUser? {
        val u = user ?: auth.currentUser ?: return null
        val email = u.email ?: u.uid
        val username = email.substringBefore("@")
        val displayName = username.replaceFirstChar { it.uppercase() }
        return AppUser(u.uid, username, displayName)
    }

    private fun resolveEmail(usernameOrEmail: String): String {
        return if (usernameOrEmail.contains("@")) usernameOrEmail else "$usernameOrEmail@gvent.app"
    }

    private suspend fun ensureProfile(uid: String, username: String, displayName: String) {
        try {
            val ref = FirebaseDatabase.getInstance().reference
                .child("gasvent")
                .child("v1")
                .child("users")
                .child(uid)

            val snapshot = ref.get().await()
            if (!snapshot.exists() || snapshot.value == null) {
                val profileMap = mapOf(
                    "username" to username,
                    "displayName" to displayName
                )
                ref.setValue(profileMap).await()
            }
        } catch (e: Throwable) {
            // ignore profile write errors
        }
    }

    override suspend fun login(username: String, password: String): Result<AppUser> {
        return try {
            val email = resolveEmail(username)
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            val firebaseUser = authResult.user ?: error("Login failed")
            val uid = firebaseUser.uid
            val derivedUsername = email.substringBefore("@")
            val displayName = derivedUsername.replaceFirstChar { it.uppercase() }
            val appUser = AppUser(uid, derivedUsername, displayName)
            _currentUser.value = appUser
            ensureProfile(uid, derivedUsername, displayName)
            Result.success(appUser)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    override suspend fun registerIfNeeded(email: String, password: String): Result<AppUser> {
        return try {
            val resolvedEmail = resolveEmail(email)
            val authResult = auth.createUserWithEmailAndPassword(resolvedEmail, password).await()
            val firebaseUser = authResult.user ?: error("Registration failed")
            val uid = firebaseUser.uid
            val derivedUsername = resolvedEmail.substringBefore("@")
            val displayName = derivedUsername.replaceFirstChar { it.uppercase() }
            val appUser = AppUser(uid, derivedUsername, displayName)
            _currentUser.value = appUser
            ensureProfile(uid, derivedUsername, displayName)
            Result.success(appUser)
        } catch (e: Throwable) {
            val message = e.message ?: ""
            if (message.contains("email-already-in-use", ignoreCase = true)) {
                try {
                    val loginResult = login(email, password)
                    if (loginResult.isSuccess) {
                        Result.success(loginResult.getOrThrow())
                    } else {
                        Result.failure(e)
                    }
                } catch (loginEx: Throwable) {
                    Result.failure(e)
                }
            } else {
                Result.failure(e)
            }
        }
    }

    override suspend fun logout() {
        try {
            auth.signOut()
        } catch (e: Throwable) {}
        _currentUser.value = null
    }
}
