package com.gvent.app.domain.export

import com.gvent.app.domain.Workspace
import com.gvent.app.domain.model.AppLanguage

interface CsvExporter {
    fun buildCsv(workspace: Workspace, lang: AppLanguage): String
}
