package com.gvent.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    background = GventBackground,
    surface = GventBackground,
    primary = GventAccentMint,
    onPrimary = GventTextOnAccent,
    error = GventError,
    onBackground = GventTextPrimary,
    onSurface = GventTextPrimary
)

@Composable
fun GventAppTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = GventTypography,
        content = content
    )
}
