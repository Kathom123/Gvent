package com.gvent.app.domain.repository

import com.gvent.app.domain.Workspace
import com.gvent.app.domain.WorkspaceOperation

interface WorkspaceRepository {
    suspend fun read(userId: String): Result<Workspace>
    suspend fun update(userId: String, operations: List<WorkspaceOperation>): Result<Workspace>
}
