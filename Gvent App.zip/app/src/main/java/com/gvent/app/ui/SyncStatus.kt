package com.gvent.app.ui

enum class SyncStatus {
    CONNECTING,
    SYNCED,
    SAVING,
    ERROR
}
