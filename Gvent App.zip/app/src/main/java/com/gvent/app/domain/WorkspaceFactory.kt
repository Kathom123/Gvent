package com.gvent.app.domain

object WorkspaceFactory {
    fun createWorkspace(): Workspace {
        return Workspace(
            schemaVersion = 1,
            revision = 0L,
            updatedAt = 0L,
            controls = Controls(
                mode = "Auto",
                speed = 45,
                running = true,
                timer = "Never",
                timerEnd = null,
                warning = 250,
                danger = 500,
                autoSafety = true,
                nightMode = false,
                alerts = true,
                simulated = false,
                muted = false
            ),
            devices = listOf(
                DemoDevice(
                    id = "sensor-gas",
                    name = "Gas sensor",
                    model = "MQ-2 · GV-S001",
                    icon = DeviceIcon.DEVICES,
                    value = "42 ppm",
                    status = "Online"
                ),
                DemoDevice(
                    id = "fan",
                    name = "Ventilation fan",
                    model = "DC Motor · GV-F001",
                    icon = DeviceIcon.WIND,
                    value = "45% speed",
                    status = "Running"
                ),
                DemoDevice(
                    id = "sensor-climate",
                    name = "Climate sensor",
                    model = "DHT22 · GV-T001",
                    icon = DeviceIcon.THERMOMETER,
                    value = "24.6 °C",
                    status = "Online"
                )
            ),
            events = listOf(
                Activity(
                    id = "seed-air",
                    title = "Air quality is back to normal",
                    detail = "Gas level dropped below 50 ppm",
                    time = "10:42 AM",
                    type = ActivityType.SHIELD,
                    tone = ActivityTone.GREEN
                ),
                Activity(
                    id = "seed-fan",
                    title = "Ventilation adjusted automatically",
                    detail = "Fan speed set to 45%",
                    time = "10:38 AM",
                    type = ActivityType.WIND,
                    tone = ActivityTone.BLUE
                ),
                Activity(
                    id = "seed-gas",
                    title = "Elevated gas level detected",
                    detail = "128 ppm · Ventilation activated",
                    time = "09:24 AM",
                    type = ActivityType.BELL,
                    tone = ActivityTone.AMBER
                )
            ),
            appliedIds = emptyList()
        )
    }
}
