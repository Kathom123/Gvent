package com.gvent.app.domain.export

import com.gvent.app.domain.Workspace
import com.gvent.app.domain.model.AppLanguage

class CsvExporterImpl : CsvExporter {
    override fun buildCsv(workspace: Workspace, lang: AppLanguage): String {
        val header = if (lang == AppLanguage.SPANISH) {
            "Hora,Evento,Detalles"
        } else {
            "Time,Event,Details"
        }
        val rows = workspace.events.map { event ->
            val time = escapeCsv(event.time)
            val title = escapeCsv(translateTitle(event.title, lang))
            val detail = escapeCsv(translateDetail(event.detail, lang))
            "$time,$title,$detail"
        }
        return "\uFEFF$header\n" + rows.joinToString("\n")
    }

    private fun escapeCsv(value: String): String {
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\""
        }
        return value
    }

    private fun translateTitle(title: String, lang: AppLanguage): String {
        if (lang == AppLanguage.SPANISH) {
            return when (title) {
                "Air quality is back to normal" -> "Calidad del aire volvió a la normalidad"
                "Ventilation adjusted automatically" -> "Ventilación ajustada automáticamente"
                "Elevated gas level detected" -> "Nivel elevado de gas detectado"
                "Ventilation stopped manually" -> "Ventilación detenida manualmente"
                "Ventilation started manually" -> "Ventilación iniciada manualmente"
                "Simulated gas alert detected" -> "Alerta de gas simulada detectada"
                "Demo device added" -> "Dispositivo de demo agregado"
                "Demo sensor calibrated" -> "Sensor de demo calibrado"
                else -> title
            }
        } else {
            return when (title) {
                "Calidad del aire volvió a la normalidad" -> "Air quality is back to normal"
                "Ventilación ajustada automáticamente" -> "Ventilation adjusted automatically"
                "Nivel elevado de gas detectado" -> "Elevated gas level detected"
                "Ventilación detenida manualmente" -> "Ventilation stopped manually"
                "Ventilación iniciada manualmente" -> "Ventilation started manually"
                "Alerta de gas simulada detectada" -> "Simulated gas alert detected"
                "Dispositivo de demo agregado" -> "Demo device added"
                "Sensor de demo calibrado" -> "Demo sensor calibrated"
                else -> title
            }
        }
    }

    private fun translateDetail(detail: String, lang: AppLanguage): String {
        if (lang == AppLanguage.SPANISH) {
            return when (detail) {
                "Gas level dropped below 50 ppm" -> "El nivel de gas cayó por debajo de 50 ppm"
                "Fan speed set to 45%" -> "Velocidad del ventilador al 45%"
                "128 ppm · Ventilation activated" -> "128 ppm · Ventilación activada"
                "612 ppm · Safety test started" -> "612 ppm · Prueba de seguridad iniciada"
                else -> detail
            }
        } else {
            return when (detail) {
                "El nivel de gas cayó por debajo de 50 ppm" -> "Gas level dropped below 50 ppm"
                "Velocidad del ventilador al 45%" -> "Fan speed set to 45%"
                "128 ppm · Ventilación activada" -> "Ventilation activated"
                "612 ppm · Prueba de seguridad iniciada" -> "Safety test started"
                else -> detail
            }
        }
    }
}
