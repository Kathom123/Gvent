package com.gvent.app.ui.theme

import androidx.compose.ui.graphics.Color

val GventBackground = Color(0xFF111514)
val GventTextPrimary = Color(0xFFE8ECE9)
val GventAccentMint = Color(0xFFA2E5BA)
val GventTextOnAccent = Color(0xFF193523)
val GventButtonBackground = Color(0xFF1B3523)
val GventSectionBorder = Color(0xFF303B31)
val GventFieldBackground = Color(0xFF191F1B)
val GventFieldBorder = Color(0xFF344037)
val GventFieldBorderFocused = Color(0xFF8DC69C)
val GventPlaceholder = Color(0xFF56675C)
val GventLabels = Color(0xFFBDCDC0)
val GventError = Color(0xFFEFB4A5)
val GventLogoBoxBackground = Color(0xFF27382B)
val GventLogoBoxBorder = Color(0xFF3D5141)
