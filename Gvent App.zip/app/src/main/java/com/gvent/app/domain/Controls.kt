package com.gvent.app.domain

import kotlinx.serialization.Serializable

@Serializable
data class Controls(
    val mode: String = "Auto",
    val speed: Int = 45,
    val running: Boolean = true,
    val timer: String = "Never",
    val timerEnd: Long? = null,
    val warning: Int = 250,
    val danger: Int = 500,
    val autoSafety: Boolean = true,
    val nightMode: Boolean = false,
    val alerts: Boolean = true,
    val simulated: Boolean = false,
    val muted: Boolean = false
)
