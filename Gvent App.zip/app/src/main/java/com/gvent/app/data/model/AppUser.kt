package com.gvent.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class AppUser(
    val uid: String,
    val username: String,
    val displayName: String
)
