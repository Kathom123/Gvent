package com.gvent.app

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.gvent.app.di.ServiceLocator
import com.gvent.app.ui.WorkspaceViewModel
import com.gvent.app.ui.dashboard.DashboardScreen
import com.gvent.app.ui.login.LoginScreen
import com.gvent.app.ui.login.LoginViewModel
import com.gvent.app.ui.theme.GventAppTheme
import com.gvent.app.ui.theme.GventBackground
import com.gvent.app.ui.theme.GventTextPrimary
import kotlinx.coroutines.launch
import java.util.Locale

val LocalAppLanguage = staticCompositionLocalOf { "es" }
val LocalSetAppLanguage = staticCompositionLocalOf<(String) -> Unit> { {} }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ServiceLocator.init(this)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val sharedPrefs = remember(context) {
                context.getSharedPreferences("gvent_prefs", Context.MODE_PRIVATE)
            }
            var langCode by remember {
                mutableStateOf(sharedPrefs.getString("gvent-language", "es") ?: "es")
            }

            fun updateLanguage(newLang: String) {
                langCode = newLang
                sharedPrefs.edit().putString("gvent-language", newLang).apply()
                val locale = Locale(newLang)
                Locale.setDefault(locale)
                val config = Configuration(resources.configuration)
                config.setLocale(locale)
                @Suppress("DEPRECATION")
                resources.updateConfiguration(config, resources.displayMetrics)
            }

            CompositionLocalProvider(
                LocalAppLanguage provides langCode,
                LocalSetAppLanguage provides ::updateLanguage
            ) {
                GventAppTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = GventBackground
                    ) {
                        if (ServiceLocator.ready) {
                            AppNav()
                        } else {
                            StartupMessage(
                                ServiceLocator.startupError
                                    ?: getString(R.string.startup_firebase_missing)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StartupMessage(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GventBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            color = GventTextPrimary,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun AppNav() {
    val navController = rememberNavController()
    val startDestination = if (Firebase.auth.currentUser != null) "dashboard" else "login"
    val scope = rememberCoroutineScope()

    NavHost(navController = navController, startDestination = startDestination) {
        composable("login") {
            val loginViewModel: LoginViewModel = viewModel()
            LoginScreen(
                loginViewModel = loginViewModel,
                onLoginSuccess = {
                    navController.navigate("dashboard") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        composable("dashboard") {
            val application = LocalContext.current.applicationContext as Application
            val workspaceViewModel: WorkspaceViewModel = viewModel {
                WorkspaceViewModel(
                    ServiceLocator.authRepository,
                    ServiceLocator.workspaceRepository,
                    application
                )
            }

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_RESUME -> workspaceViewModel.setVisible(true)
                        Lifecycle.Event.ON_PAUSE -> workspaceViewModel.setVisible(false)
                        else -> {}
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            LaunchedEffect(Unit) {
                workspaceViewModel.sessionExpired.collect {
                    if (Firebase.auth.currentUser == null) {
                        navController.navigate("login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            }

            DashboardScreen(
                workspaceViewModel = workspaceViewModel,
                onLogout = {
                    scope.launch {
                        ServiceLocator.authRepository.logout()
                        navController.navigate("login") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }
    }
}
