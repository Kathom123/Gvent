package com.gvent.app.domain

import kotlinx.serialization.json.Json

val WorkspaceJson = Json {
    encodeDefaults = true
    ignoreUnknownKeys = true
}
