package com.gvent.app.ui.login

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gvent.app.R
import com.gvent.app.ui.theme.*

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.gvent.app.LocalAppLanguage
import com.gvent.app.LocalSetAppLanguage

@Composable
fun LoginScreen(
    loginViewModel: LoginViewModel,
    onLoginSuccess: () -> Unit
) {
    val uiState by loginViewModel.uiState.collectAsState()
    val passwordFocusRequester = remember { FocusRequester() }
    val currentLang = LocalAppLanguage.current
    val setAppLanguage = LocalSetAppLanguage.current

    LaunchedEffect(Unit) {
        loginViewModel.loginSuccess.collect { onLoginSuccess() }
    }

    LaunchedEffect(uiState.error) {
        if (uiState.error != null) {
            loginViewModel.clearPassword()
            try {
                passwordFocusRequester.requestFocus()
            } catch (_: IllegalStateException) {
                // The field may not be attached yet. The error text is enough.
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GventBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(GventAccentMint, shape = RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = null,
                        tint = GventTextOnAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = stringResource(R.string.gvent_brand),
                    fontFamily = ManropeFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = GventTextPrimary
                )
            }

            TextButton(
                onClick = { setAppLanguage(if (currentLang == "es") "en" else "es") }
            ) {
                Text(
                    text = if (currentLang == "es") "ES" else "EN",
                    color = GventAccentMint,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Center content card box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .widthIn(max = 380.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Lock icon box
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(GventLogoBoxBackground, shape = RoundedCornerShape(14.dp))
                    .border(1.dp, GventLogoBoxBorder, shape = RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = GventAccentMint,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Title
            Text(
                text = stringResource(R.string.login_title),
                fontFamily = ManropeFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 31.sp,
                color = GventTextPrimary
            )

            // Username field
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.login_username_label),
                    fontFamily = DmSansFontFamily,
                    fontSize = 14.sp,
                    color = GventLabels
                )
                OutlinedTextField(
                    value = uiState.username,
                    onValueChange = {
                        if (it.length <= 80) {
                            loginViewModel.onUsernameChanged(it)
                        }
                    },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.login_username_placeholder),
                            fontFamily = DmSansFontFamily,
                            color = GventPlaceholder
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = GventPlaceholder
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(9.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GventTextPrimary,
                        unfocusedTextColor = GventTextPrimary,
                        focusedContainerColor = GventFieldBackground,
                        unfocusedContainerColor = GventFieldBackground,
                        focusedBorderColor = GventFieldBorderFocused,
                        unfocusedBorderColor = GventFieldBorder
                    )
                )
            }

            // Password field
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.login_password_label),
                    fontFamily = DmSansFontFamily,
                    fontSize = 14.sp,
                    color = GventLabels
                )
                OutlinedTextField(
                    value = uiState.password,
                    onValueChange = { loginViewModel.onPasswordChanged(it) },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.login_password_placeholder),
                            fontFamily = DmSansFontFamily,
                            color = GventPlaceholder
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = GventPlaceholder
                        )
                    },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { loginViewModel.login() }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(passwordFocusRequester),
                    shape = RoundedCornerShape(9.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = GventTextPrimary,
                        unfocusedTextColor = GventTextPrimary,
                        focusedContainerColor = GventFieldBackground,
                        unfocusedContainerColor = GventFieldBackground,
                        focusedBorderColor = GventFieldBorderFocused,
                        unfocusedBorderColor = GventFieldBorder
                    )
                )
            }

            // Error area (reserved min height)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 36.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (uiState.error != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = GventError,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = uiState.error!!,
                            color = GventError,
                            fontFamily = DmSansFontFamily,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Submit Button
            Button(
                onClick = { loginViewModel.login() },
                enabled = !uiState.pending,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(9.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GventAccentMint,
                    disabledContainerColor = GventAccentMint.copy(alpha = 0.6f)
                )
            ) {
                if (uiState.pending) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = GventButtonBackground,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = stringResource(R.string.login_verifying),
                            fontFamily = DmSansFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = GventButtonBackground,
                            fontSize = 16.sp
                        )
                    }
                } else {
                    Text(
                        text = stringResource(R.string.login_button),
                        fontFamily = DmSansFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = GventButtonBackground,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}
}
