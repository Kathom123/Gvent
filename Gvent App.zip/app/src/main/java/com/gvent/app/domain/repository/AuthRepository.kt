package com.gvent.app.domain.repository

import com.gvent.app.data.model.AppUser
import kotlinx.coroutines.flow.StateFlow

interface AuthRepository {
    suspend fun login(username: String, password: String): Result<AppUser>
    suspend fun registerIfNeeded(email: String, password: String): Result<AppUser>
    suspend fun logout()
    val currentUser: StateFlow<AppUser?>
}
