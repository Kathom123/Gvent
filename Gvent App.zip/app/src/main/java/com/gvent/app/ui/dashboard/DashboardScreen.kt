package com.gvent.app.ui.dashboard

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.gvent.app.LocalAppLanguage
import com.gvent.app.LocalSetAppLanguage
import com.gvent.app.R
import com.gvent.app.di.ServiceLocator
import com.gvent.app.domain.ActivityTone
import com.gvent.app.domain.ActivityType
import com.gvent.app.domain.DeviceIcon
import com.gvent.app.domain.Workspace
import com.gvent.app.domain.export.CsvExporterImpl
import com.gvent.app.domain.model.AppLanguage
import com.gvent.app.ui.SyncStatus
import com.gvent.app.ui.WorkspaceViewModel
import com.gvent.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    workspaceViewModel: WorkspaceViewModel,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val lang = LocalAppLanguage.current
    val setAppLanguage = LocalSetAppLanguage.current

    val workspace by workspaceViewModel.workspace.collectAsState()
    val syncStatus by workspaceViewModel.syncStatus.collectAsState()
    val syncError by workspaceViewModel.syncError.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Overview, 1: Devices
    var showProfileModal by remember { mutableStateOf(false) }
    var showHelpModal by remember { mutableStateOf(false) }
    var showAddDeviceDialog by remember { mutableStateOf(false) }
    var showCalibrationDialog by remember { mutableStateOf(false) }
    var calibrating by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val csvExporter = remember { CsvExporterImpl() }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            try {
                val csvContent = csvExporter.buildCsv(workspace, if (lang == "es") AppLanguage.SPANISH else AppLanguage.ENGLISH)
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(csvContent.toByteArray(Charsets.UTF_8))
                }
                scope.launch {
                    snackbarHostState.showSnackbar(
                        context.getString(R.string.report_saved)
                    )
                }
            } catch (e: Exception) {
                scope.launch {
                    snackbarHostState.showSnackbar(
                        context.getString(R.string.report_save_error)
                    )
                }
            }
        } else {
            scope.launch {
                snackbarHostState.showSnackbar(
                    context.getString(R.string.report_cancelled)
                )
            }
        }
    }

    var simulatedGas by remember { mutableStateOf(42) }
    LaunchedEffect(workspace.controls.simulated, workspace.controls.running) {
        while (true) {
            delay(2000)
            simulatedGas = if (workspace.controls.simulated) {
                612
            } else {
                val base = if (workspace.controls.running) 35 else 120
                (base + (Math.random() * 20).toInt()).coerceIn(20, 900)
            }
        }
    }

    Scaffold(
        containerColor = GventBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(GventAccentMint, shape = RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Air,
                                contentDescription = null,
                                tint = GventTextOnAccent,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = stringResource(R.string.gvent_brand),
                            fontFamily = ManropeFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = GventTextPrimary
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = { setAppLanguage(if (lang == "es") "en" else "es") },
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(
                            text = if (lang == "es") "ES" else "EN",
                            color = GventAccentMint,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clickable {
                                if (syncStatus == SyncStatus.ERROR && syncError != null) {
                                    scope.launch { snackbarHostState.showSnackbar(syncError!!) }
                                }
                                workspaceViewModel.retry()
                            }
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val dotColor = when (syncStatus) {
                                SyncStatus.SYNCED -> Color(0xFF4CAF50)
                                SyncStatus.SAVING -> Color(0xFFFFC107)
                                SyncStatus.CONNECTING -> Color(0xFF00BCD4)
                                SyncStatus.ERROR -> GventError
                            }
                            Box(modifier = Modifier.size(8.dp).background(dotColor, CircleShape))
                            Text(
                                text = when (syncStatus) {
                                    SyncStatus.CONNECTING -> stringResource(R.string.sync_connecting)
                                    SyncStatus.SYNCED -> stringResource(R.string.sync_synced)
                                    SyncStatus.SAVING -> stringResource(R.string.sync_saving)
                                    SyncStatus.ERROR -> stringResource(R.string.sync_error)
                                },
                                fontSize = 11.sp,
                                color = GventLabels,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(onClick = { showProfileModal = true }) {
                        val userEmail = Firebase.auth.currentUser?.email ?: "U"
                        val initials = userEmail.take(2).uppercase()
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(GventAccentMint, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = initials,
                                color = GventTextOnAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = GventBackground)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = GventFieldBackground) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.GridView, contentDescription = null) },
                    label = { Text(stringResource(R.string.overview)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GventAccentMint,
                        selectedTextColor = GventAccentMint,
                        unselectedIconColor = GventPlaceholder,
                        unselectedTextColor = GventPlaceholder,
                        indicatorColor = GventLogoBoxBackground
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Devices, contentDescription = null) },
                    label = { Text(stringResource(R.string.devices)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GventAccentMint,
                        selectedTextColor = GventAccentMint,
                        unselectedIconColor = GventPlaceholder,
                        unselectedTextColor = GventPlaceholder,
                        indicatorColor = GventLogoBoxBackground
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (selectedTab == 0) {
                OverviewPage(
                    workspace = workspace,
                    simulatedGas = simulatedGas,
                    lang = lang,
                    viewModel = workspaceViewModel,
                    onExportCsv = {
                        exportLauncher.launch("Gvent-activity.csv")
                    },
                    onOpenCalibration = { showCalibrationDialog = true },
                    onOpenHelp = { showHelpModal = true }
                )
            } else {
                DevicesPage(
                    workspace = workspace,
                    lang = lang,
                    onAddDeviceClick = { showAddDeviceDialog = true },
                    onLogEvent = { title, detail ->
                        workspaceViewModel.addActivity(title, detail)
                        scope.launch {
                            snackbarHostState.showSnackbar(context.getString(R.string.report_saved))
                        }
                    }
                )
            }
        }
    }

    if (showAddDeviceDialog) {
        var devName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDeviceDialog = false },
            title = { Text(stringResource(R.string.add_device)) },
            text = {
                OutlinedTextField(
                    value = devName,
                    onValueChange = { if (it.length <= 40) devName = it },
                    label = { Text(stringResource(R.string.device_name_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (devName.isNotBlank()) {
                            workspaceViewModel.addDevice(devName.trim())
                            devName = ""
                            showAddDeviceDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GventAccentMint)
                ) {
                    Text(stringResource(R.string.save), color = GventTextOnAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDeviceDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (showCalibrationDialog) {
        AlertDialog(
            onDismissRequest = { if (!calibrating) showCalibrationDialog = false },
            title = { Text(stringResource(R.string.calibrate_sensors)) },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (calibrating) {
                        CircularProgressIndicator(color = GventAccentMint)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(stringResource(R.string.calibrating), color = GventTextPrimary)
                    } else {
                        Text(stringResource(R.string.keep_clean_air), color = GventLabels)
                    }
                }
            },
            confirmButton = {
                if (!calibrating) {
                    Button(
                        onClick = {
                            calibrating = true
                            scope.launch {
                                delay(2000)
                                calibrating = false
                                showCalibrationDialog = false
                                val doneTitle = if (lang == "es") "Calibración completada" else "Calibration completed"
                                val doneDetail = if (lang == "es") "Sensores de gas recalibrados" else "Gas sensors recalibrated"
                                workspaceViewModel.addActivity(doneTitle, doneDetail)
                                snackbarHostState.showSnackbar(context.getString(R.string.calibration_detail))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GventAccentMint)
                    ) {
                        Text(stringResource(R.string.calibrate_sensors), color = GventTextOnAccent)
                    }
                }
            },
            dismissButton = {
                if (!calibrating) {
                    TextButton(onClick = { showCalibrationDialog = false }) {
                        Text(stringResource(R.string.close))
                    }
                }
            }
        )
    }

    if (showProfileModal) {
        val user = Firebase.auth.currentUser
        AlertDialog(
            onDismissRequest = { showProfileModal = false },
            title = { Text(stringResource(R.string.profile), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("UID: ${user?.uid ?: "N/A"}", color = GventLabels, fontSize = 13.sp)
                    Text("Email: ${user?.email ?: "N/A"}", color = GventTextPrimary, fontSize = 14.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showProfileModal = false
                        scope.launch {
                            ServiceLocator.authRepository.logout()
                            onLogout()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GventError)
                ) {
                    Text(stringResource(R.string.logout), color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileModal = false }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }

    if (showHelpModal) {
        AlertDialog(
            onDismissRequest = { showHelpModal = false },
            title = { Text(stringResource(R.string.help_support), fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.help_auto_title), fontWeight = FontWeight.Bold, color = GventTextPrimary)
                    Text(stringResource(R.string.help_auto_desc), color = GventLabels, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(stringResource(R.string.help_conn_title), fontWeight = FontWeight.Bold, color = GventTextPrimary)
                    Text(stringResource(R.string.help_conn_desc), color = GventLabels, fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showHelpModal = false }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }
}

@Composable
fun OverviewPage(
    workspace: Workspace,
    simulatedGas: Int,
    lang: String,
    viewModel: WorkspaceViewModel,
    onExportCsv: () -> Unit,
    onOpenCalibration: () -> Unit,
    onOpenHelp: () -> Unit
) {
    val controls = workspace.controls
    val hazard = simulatedGas >= controls.danger
    val caution = !hazard && simulatedGas >= controls.warning
    var historyPeriod by remember { mutableStateOf("24h") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Air Gas Sensor Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(
                                        when {
                                            hazard -> GventError
                                            caution -> Color(0xFFFFC107)
                                            else -> Color(0xFF4CAF50)
                                        },
                                        CircleShape
                                    )
                            )
                            Text(
                                text = stringResource(R.string.air_sensor_title),
                                fontFamily = ManropeFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = GventTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = "$simulatedGas ppm",
                            fontFamily = ManropeFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp,
                            color = GventAccentMint
                        )
                    }

                    val infiniteTransition = rememberInfiniteTransition(label = "fan")
                    val angle by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "fan_rotation"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Air,
                                contentDescription = null,
                                tint = GventAccentMint,
                                modifier = Modifier.size(28.dp).rotate(if (controls.running && !controls.muted) angle else 0f)
                            )
                            Text(
                                text = if (controls.running) stringResource(R.string.fan_running) else stringResource(R.string.fan_standby),
                                color = GventLabels,
                                fontSize = 14.sp
                            )
                        }
                        Button(
                            onClick = {
                                val newRunning = !controls.running
                                viewModel.setRunning(newRunning)
                                val logTitle = if (newRunning) {
                                    if (lang == "es") "Ventilación iniciada manualmente" else "Ventilation started manually"
                                } else {
                                    if (lang == "es") "Ventilación detenida manualmente" else "Ventilation stopped manually"
                                }
                                val logDetail = if (lang == "es") "Control manual" else "Manual control"
                                viewModel.addActivity(logTitle, logDetail)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (controls.running) GventError else GventAccentMint
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = stringResource(if (controls.running) R.string.turn_off_fan else R.string.turn_on_fan),
                                color = if (controls.running) Color.White else GventTextOnAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Quick Stats Card (Adaptive 3 columns)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.quick_stats),
                        fontFamily = ManropeFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GventTextPrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatBox(
                            modifier = Modifier.weight(1f),
                            title = stringResource(R.string.air_quality),
                            value = if (hazard) stringResource(R.string.air_dangerous) else if (caution) stringResource(R.string.air_moderate) else stringResource(R.string.air_good)
                        )
                        StatBox(
                            modifier = Modifier.weight(1f),
                            title = stringResource(R.string.power),
                            value = stringResource(R.string.speed_unit, controls.speed)
                        )
                        StatBox(
                            modifier = Modifier.weight(1f),
                            title = stringResource(R.string.fan_status),
                            value = if (controls.running) stringResource(R.string.fan_running) else stringResource(R.string.fan_standby)
                        )
                    }
                }
            }
        }

        // Gas Concentration History Chart Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.gas_history),
                            fontFamily = ManropeFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = GventTextPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("24h" to stringResource(R.string.period_24h), "7d" to stringResource(R.string.period_7d), "30d" to stringResource(R.string.period_30d)).forEach { (key, label) ->
                                val isSelected = historyPeriod == key
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isSelected) GventAccentMint else GventFieldBackground,
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .clickable { historyPeriod = key }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = key,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) GventTextOnAccent else GventLabels
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(GventFieldBackground, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        val points = remember(historyPeriod, simulatedGas) {
                            when (historyPeriod) {
                                "7d" -> listOf(38f, 42f, 48f, 55f, 50f, 44f, simulatedGas.toFloat())
                                "30d" -> listOf(32f, 35f, 40f, 60f, 45f, 38f, simulatedGas.toFloat())
                                else -> listOf(40f, 45f, 50f, 42f, 60f, 55f, simulatedGas.toFloat())
                            }
                        }
                        val warningPpm = controls.warning.toFloat()
                        val dangerPpm = controls.danger.toFloat()

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val maxVal = 800f
                            val width = size.width
                            val height = size.height
                            val stepX = width / (points.size - 1).coerceAtLeast(1)

                            // Warning threshold line
                            val warnY = height - (warningPpm / maxVal) * height
                            if (warnY in 0f..height) {
                                drawLine(
                                    color = Color(0xFFFFC107).copy(alpha = 0.4f),
                                    start = androidx.compose.ui.geometry.Offset(0f, warnY),
                                    end = androidx.compose.ui.geometry.Offset(width, warnY),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f),
                                    strokeWidth = 2f
                                )
                            }

                            // Danger threshold line
                            val dangerY = height - (dangerPpm / maxVal) * height
                            if (dangerY in 0f..height) {
                                drawLine(
                                    color = GventError.copy(alpha = 0.5f),
                                    start = androidx.compose.ui.geometry.Offset(0f, dangerY),
                                    end = androidx.compose.ui.geometry.Offset(width, dangerY),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f),
                                    strokeWidth = 2f
                                )
                            }

                            // Chart path & fill
                            val path = Path()
                            val fillPath = Path()
                            fillPath.moveTo(0f, height)

                            points.forEachIndexed { index, v ->
                                val x = index * stepX
                                val y = height - (v / maxVal) * height
                                if (index == 0) {
                                    path.moveTo(x, y)
                                    fillPath.lineTo(x, y)
                                } else {
                                    path.lineTo(x, y)
                                    fillPath.lineTo(x, y)
                                }
                            }
                            fillPath.lineTo(width, height)
                            fillPath.close()

                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        GventAccentMint.copy(alpha = 0.25f),
                                        GventAccentMint.copy(alpha = 0.02f)
                                    )
                                )
                            )
                            drawPath(path, color = GventAccentMint, style = Stroke(width = 3f))
                        }
                    }
                }
            }
        }

        // Safety First Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.safety_first),
                        fontFamily = ManropeFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GventTextPrimary
                    )
                    if (controls.simulated && controls.autoSafety && controls.danger <= 612) {
                        Text(
                            text = stringResource(R.string.safety_test_notice),
                            color = GventError,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.auto_safety_vent),
                            color = GventLabels,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = controls.autoSafety,
                            onCheckedChange = { viewModel.setAutoSafety(it) },
                            enabled = !(controls.simulated && controls.autoSafety && controls.danger <= 612)
                        )
                    }
                }
            }
        }

        // Quieter Evening Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.quieter_evening),
                        fontFamily = ManropeFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GventTextPrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.night_mode),
                            color = GventLabels,
                            fontSize = 14.sp
                        )
                        Switch(
                            checked = controls.nightMode,
                            onCheckedChange = { viewModel.setNightMode(it) }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.alerts),
                            color = GventLabels,
                            fontSize = 14.sp
                        )
                        Switch(
                            checked = controls.alerts,
                            onCheckedChange = { viewModel.setAlerts(it) }
                        )
                    }
                }
            }
        }

        // Gas Thresholds Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.gas_thresholds),
                        fontFamily = ManropeFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GventTextPrimary
                    )

                    Column {
                        Text(
                            text = stringResource(R.string.warning_threshold_val, controls.warning),
                            color = GventLabels,
                            fontSize = 13.sp
                        )
                        Slider(
                            value = controls.warning.toFloat(),
                            onValueChange = { newWarn ->
                                val w = newWarn.toInt()
                                if (controls.danger - w >= 50) {
                                    viewModel.setWarning(w)
                                }
                            },
                            valueRange = 50f..950f
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.danger_threshold_val, controls.danger),
                            color = GventLabels,
                            fontSize = 13.sp
                        )
                        Slider(
                            value = controls.danger.toFloat(),
                            onValueChange = { newDang ->
                                val d = newDang.toInt()
                                if (d - controls.warning >= 50) {
                                    viewModel.setDanger(d)
                                }
                            },
                            valueRange = 100f..1000f
                        )
                    }
                }
            }
        }

        // System Preferences Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = stringResource(R.string.system_preferences),
                        fontFamily = ManropeFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = GventTextPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setMode("Auto") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (controls.mode == "Auto") GventAccentMint else GventFieldBackground
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = stringResource(R.string.mode_auto),
                                color = if (controls.mode == "Auto") GventTextOnAccent else GventTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Button(
                            onClick = { viewModel.setMode("Manual") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (controls.mode == "Manual") GventAccentMint else GventFieldBackground
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = stringResource(R.string.mode_manual),
                                color = if (controls.mode == "Manual") GventTextOnAccent else GventTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.fan_speed_label, controls.speed),
                            color = GventLabels,
                            fontSize = 13.sp
                        )
                        Slider(
                            value = controls.speed.toFloat(),
                            onValueChange = { viewModel.setSpeed(it.toInt()) },
                            valueRange = 0f..100f
                        )
                    }

                    Text(
                        text = stringResource(R.string.timer_label, getTimerLabel(controls.timer, lang)),
                        color = GventLabels,
                        fontSize = 13.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "Never" to stringResource(R.string.timer_never),
                            "15 min" to stringResource(R.string.timer_15min),
                            "30 min" to stringResource(R.string.timer_30min),
                            "60 min" to stringResource(R.string.timer_60min)
                        ).forEach { (key, label) ->
                            val isSelected = controls.timer == key
                            Button(
                                onClick = {
                                    viewModel.setTimer(key)
                                    val minutes = when (key) {
                                        "15 min" -> 15L
                                        "30 min" -> 30L
                                        "60 min" -> 60L
                                        else -> 0L
                                    }
                                    val end = if (minutes > 0) System.currentTimeMillis() + minutes * 60_000L else null
                                    viewModel.setTimerEnd(end)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) GventAccentMint else GventFieldBackground
                                ),
                                modifier = Modifier.weight(1f).height(38.dp),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) GventTextOnAccent else GventTextPrimary,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.simulation_mode),
                            color = GventLabels,
                            fontSize = 14.sp
                        )
                        Switch(
                            checked = controls.simulated,
                            onCheckedChange = { viewModel.setSimulated(it) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onExportCsv,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = GventFieldBackground)
                        ) {
                            Text(
                                text = stringResource(R.string.export_csv),
                                color = GventTextPrimary,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Button(
                            onClick = onOpenCalibration,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = GventFieldBackground)
                        ) {
                            Text(
                                text = stringResource(R.string.calibrate_sensors),
                                color = GventTextPrimary,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatBox(
    modifier: Modifier = Modifier,
    title: String,
    value: String
) {
    Column(
        modifier = modifier
            .background(GventFieldBackground, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 10.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            color = GventLabels,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontFamily = ManropeFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = GventTextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DevicesPage(
    workspace: Workspace,
    lang: String,
    onAddDeviceClick: () -> Unit,
    onLogEvent: (String, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.connected_devices_title, workspace.devices.size),
                    fontFamily = ManropeFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = GventTextPrimary,
                    modifier = Modifier.padding(end = 12.dp)
                )
                IconButton(
                    onClick = onAddDeviceClick,
                    modifier = Modifier
                        .size(34.dp)
                        .background(GventAccentMint, shape = RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = stringResource(R.string.add_device),
                        tint = GventTextOnAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        items(workspace.devices) { device ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(GventFieldBackground, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (device.icon) {
                                    DeviceIcon.DEVICES -> Icons.Default.Devices
                                    DeviceIcon.WIND -> Icons.Default.Air
                                    DeviceIcon.THERMOMETER -> Icons.Default.Thermostat
                                },
                                contentDescription = null,
                                tint = GventAccentMint
                            )
                        }
                        Column {
                            Text(
                                text = getDeviceName(device.name, lang),
                                fontFamily = ManropeFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = GventTextPrimary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = device.model,
                                fontSize = 12.sp,
                                color = GventLabels
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = getDeviceValue(device.value, lang),
                            fontWeight = FontWeight.Bold,
                            color = GventAccentMint,
                            fontSize = 14.sp
                        )
                        Text(
                            text = getDeviceStatus(device.status, lang),
                            fontSize = 12.sp,
                            color = GventPlaceholder
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.recent_activity),
                    fontFamily = ManropeFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = GventTextPrimary
                )
                Button(
                    onClick = {
                        val title = if (lang == "es") "Registro manual" else "Manual log"
                        val detail = if (lang == "es") "Actividad registrada desde la app móvil" else "Activity logged from mobile app"
                        onLogEvent(title, detail)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GventFieldBackground),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = stringResource(R.string.register_event),
                        color = GventTextPrimary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        items(workspace.events) { event ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF182019)),
                border = BorderStroke(1.dp, GventSectionBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                when (event.tone) {
                                    ActivityTone.GREEN -> Color(0xFF193523)
                                    ActivityTone.BLUE -> Color(0xFF1A2A3A)
                                    ActivityTone.AMBER -> Color(0xFF3A2A1A)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (event.type) {
                                ActivityType.SHIELD -> Icons.Default.Security
                                ActivityType.WIND -> Icons.Default.Air
                                ActivityType.BELL -> Icons.Default.Notifications
                                ActivityType.CHECK -> Icons.Default.Check
                            },
                            contentDescription = null,
                            tint = when (event.tone) {
                                ActivityTone.GREEN -> GventAccentMint
                                ActivityTone.BLUE -> Color(0xFF8DB4E2)
                                ActivityTone.AMBER -> Color(0xFFE2B48D)
                            },
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = getEventTitle(event.title, lang),
                            fontWeight = FontWeight.Bold,
                            color = GventTextPrimary,
                            fontSize = 14.sp
                        )
                        Text(
                            text = getEventDetail(event.detail, lang),
                            fontSize = 12.sp,
                            color = GventLabels
                        )
                        Text(
                            text = getEventTime(event.time, lang),
                            fontSize = 11.sp,
                            color = GventPlaceholder
                        )
                    }
                }
            }
        }
    }
}

fun getDeviceName(name: String, lang: String): String {
    if (lang == "en") {
        return when (name) {
            "Sensor de gas" -> "Gas sensor"
            "Ventilador de ventilación" -> "Ventilation fan"
            "Sensor de clima" -> "Climate sensor"
            else -> name
        }
    } else {
        return when (name) {
            "Gas sensor" -> "Sensor de gas"
            "Ventilation fan" -> "Ventilador de ventilación"
            "Climate sensor" -> "Sensor de clima"
            else -> name
        }
    }
}

fun getDeviceValue(value: String, lang: String): String {
    if (lang == "es") {
        if (value.contains("speed", ignoreCase = true)) {
            return value.replace("speed", "de velocidad", ignoreCase = true)
        }
    } else {
        if (value.contains("de velocidad", ignoreCase = true)) {
            return value.replace("de velocidad", "speed", ignoreCase = true)
        }
    }
    return value
}

fun getDeviceStatus(status: String, lang: String): String {
    if (lang == "en") {
        return when (status) {
            "En línea" -> "Online"
            "Desconectado" -> "Offline"
            "En ejecución" -> "Running"
            "En espera" -> "Standby"
            else -> status
        }
    } else {
        return when (status) {
            "Online" -> "En línea"
            "Offline" -> "Desconectado"
            "Running" -> "En ejecución"
            "Standby" -> "En espera"
            else -> status
        }
    }
}

fun getEventTitle(title: String, lang: String): String {
    if (lang == "en") {
        return when (title) {
            "Calidad del aire volvió a la normalidad" -> "Air quality is back to normal"
            "Ventilación ajustada automáticamente" -> "Ventilation adjusted automatically"
            "Nivel elevado de gas detectado" -> "Elevated gas level detected"
            "Ventilación detenida manualmente" -> "Ventilation stopped manually"
            "Ventilación iniciada manualmente" -> "Ventilation started manually"
            "Alerta de gas simulada detectada" -> "Simulated gas alert detected"
            "Dispositivo de demo agregado" -> "Demo device added"
            "Sensor de demo calibrado" -> "Demo sensor calibrated"
            "Calibración completada" -> "Calibration completed"
            "Registro manual" -> "Manual log"
            else -> title
        }
    } else {
        return when (title) {
            "Air quality is back to normal" -> "Calidad del aire volvió a la normalidad"
            "Ventilation adjusted automatically" -> "Ventilación ajustada automáticamente"
            "Elevated gas level detected" -> "Nivel elevado de gas detectado"
            "Ventilation stopped manually" -> "Ventilación detenida manualmente"
            "Ventilation started manually" -> "Ventilación iniciada manualmente"
            "Simulated gas alert detected" -> "Alerta de gas simulada detectada"
            "Demo device added" -> "Dispositivo de demo agregado"
            "Demo sensor calibrated" -> "Sensor de demo calibrado"
            "Calibration completed" -> "Calibración completada"
            "Manual log" -> "Registro manual"
            else -> title
        }
    }
}

fun getEventDetail(detail: String, lang: String): String {
    if (lang == "en") {
        return when (detail) {
            "El nivel de gas cayó por debajo de 50 ppm" -> "Gas level dropped below 50 ppm"
            "Velocidad del ventilador al 45%" -> "Fan speed set to 45%"
            "128 ppm · Ventilación activada" -> "128 ppm · Ventilation activated"
            "Cocina · Control manual" -> "Kitchen · Manual control"
            "Sala · Control manual" -> "Living room · Manual control"
            "Garaje · Control manual" -> "Garage · Manual control"
            "612 ppm · Prueba de seguridad iniciada" -> "612 ppm · Safety test started"
            "Sensores de gas recalibrados" -> "Recalibrated gas sensors"
            "Actividad registrada desde la app móvil" -> "Activity logged from mobile app"
            else -> detail
        }
    } else {
        return when (detail) {
            "Gas level dropped below 50 ppm" -> "El nivel de gas cayó por debajo de 50 ppm"
            "Fan speed set to 45%" -> "Velocidad del ventilador al 45%"
            "128 ppm · Ventilation activated" -> "128 ppm · Ventilación activada"
            "Kitchen · Manual control" -> "Cocina · Control manual"
            "Living room · Manual control" -> "Sala · Control manual"
            "Garage · Manual control" -> "Garaje · Control manual"
            "612 ppm · Safety test started" -> "612 ppm · Prueba de seguridad iniciada"
            "Recalibrated gas sensors" -> "Sensores de gas recalibrados"
            "Activity logged from mobile app" -> "Actividad registrada desde la app móvil"
            else -> detail
        }
    }
}

fun getEventTime(time: String, lang: String): String {
    if (time.isEmpty()) return time
    if (lang == "es") {
        if (time.equals("just now", ignoreCase = true)) return "Ahora mismo"
        if (time.equals("a moment ago", ignoreCase = true)) return "Hace un momento"
        if (time.equals("yesterday", ignoreCase = true)) return "Ayer"
        if (time.contains("ago", ignoreCase = true)) {
            val parts = time.split(" ")
            if (parts.isNotEmpty()) {
                val n = parts[0]
                val unit = parts.getOrNull(1)?.lowercase() ?: "min"
                if (unit.startsWith("min")) return "Hace $n min"
                return "Hace $n h"
            }
        }
    } else {
        if (time.equals("ahora mismo", ignoreCase = true)) return "Just now"
        if (time.equals("hace un momento", ignoreCase = true)) return "A moment ago"
        if (time.equals("ayer", ignoreCase = true)) return "Yesterday"
        if (time.startsWith("hace", ignoreCase = true)) {
            val parts = time.split(" ")
            if (parts.size >= 2) {
                val n = parts[1]
                val unit = parts.getOrNull(2)?.lowercase() ?: "min"
                if (unit.startsWith("min")) return "$n min ago"
                return "$n hr ago"
            }
        }
    }
    return time
}

fun getTimerLabel(key: String, lang: String): String {
    return when (key) {
        "Never" -> if (lang == "es") "Nunca" else "Never"
        "15 min" -> "15 min"
        "30 min" -> "30 min"
        "60 min" -> "60 min"
        else -> key
    }
}
