package com.gvent.app.domain

class WorkspaceValidationException(message: String) : RuntimeException(message)

object WorkspaceValidator {
    fun validate(controls: Controls) {
        if (controls.speed !in 0..100) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
        if (controls.warning < 50) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
        if (controls.danger > 1000) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
        if (controls.danger - controls.warning < 50) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
        if (controls.mode !in listOf("Auto", "Manual")) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
        if (controls.timer !in listOf("Never", "15 min", "30 min", "60 min")) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
        if (controls.timerEnd != null && controls.timerEnd < 0) {
            throw WorkspaceValidationException("Control values are out of range.")
        }
    }

    fun validText(value: String?, max: Int): Boolean {
        if (value == null) return false
        val trimmed = value.trim()
        return trimmed.isNotEmpty() && value.length <= max
    }

    fun validateWorkspace(workspace: Workspace) {
        if (workspace.schemaVersion != 1 || workspace.revision < 0 || workspace.updatedAt < 0) {
            throw WorkspaceValidationException("Unsupported workspace format.")
        }
        validate(workspace.controls)
        if (workspace.devices.size > 32) {
            throw WorkspaceValidationException("Invalid device list.")
        }
        for (device in workspace.devices) {
            if (!validText(device.id, 80) ||
                !validText(device.name, 40) ||
                !validText(device.model, 100) ||
                !validText(device.value, 40) ||
                !validText(device.status, 30)) {
                throw WorkspaceValidationException("Invalid device list.")
            }
        }
        if (workspace.events.size > 100) {
            throw WorkspaceValidationException("Invalid activity list.")
        }
        for (event in workspace.events) {
            if (!validText(event.id, 80) ||
                !validText(event.title, 120) ||
                !validText(event.detail, 240) ||
                !validText(event.time, 40)) {
                throw WorkspaceValidationException("Invalid activity list.")
            }
        }
        if (workspace.appliedIds.size > 256 || workspace.appliedIds.any { !validText(it, 80) }) {
            throw WorkspaceValidationException("Invalid operation history.")
        }
    }
}
