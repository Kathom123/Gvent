package com.gvent.app.data.firebase

import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseException
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.ktx.Firebase
import com.gvent.app.domain.Workspace
import com.gvent.app.domain.WorkspaceFactory
import com.gvent.app.domain.WorkspaceJson
import com.gvent.app.domain.WorkspaceOperation
import com.gvent.app.domain.WorkspaceReducer
import com.gvent.app.domain.WorkspaceValidationException
import com.gvent.app.domain.WorkspaceValidator
import com.gvent.app.domain.error.ErrorCodes
import com.gvent.app.domain.repository.WorkspaceRepository
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class FirebaseWorkspaceRepository : WorkspaceRepository {

    private fun getRef(userId: String): DatabaseReference {
        return FirebaseDatabase.getInstance().reference
            .child("gasvent")
            .child("v1")
            .child("workspaces")
            .child(userId)
            .child("simulation")
    }

    private fun anyToJsonElement(any: Any?): JsonElement {
        return when (any) {
            null -> JsonNull
            is Boolean -> JsonPrimitive(any)
            is Number -> JsonPrimitive(any)
            is String -> JsonPrimitive(any)
            is Map<*, *> -> JsonObject(any.entries.associate { it.key.toString() to anyToJsonElement(it.value) })
            is Iterable<*> -> JsonArray(any.map { anyToJsonElement(it) })
            else -> JsonPrimitive(any.toString())
        }
    }

    private fun jsonElementToAny(element: JsonElement): Any? {
        return when (element) {
            is JsonNull -> null
            is JsonPrimitive -> {
                if (element.isString) element.content
                else {
                    element.intOrNull ?: element.longOrNull ?: element.doubleOrNull ?: element.content
                }
            }
            is JsonObject -> element.entries.associate { it.key to jsonElementToAny(it.value) }
            is JsonArray -> element.map { jsonElementToAny(it) }
        }
    }

    private fun parseWorkspaceSafely(jsonObject: JsonObject): Workspace {
        try {
            val workspace = WorkspaceJson.decodeFromJsonElement(Workspace.serializer(), jsonObject)
            WorkspaceValidator.validateWorkspace(workspace)
            return workspace
        } catch (e: Exception) {
            throw WorkspaceValidationException(ErrorCodes.INVALID_OPERATION)
        }
    }

    override suspend fun read(userId: String): Result<Workspace> {
        return try {
            val ref = getRef(userId)
            val snapshot = withTimeout(12000L) {
                suspendCancellableCoroutine<DataSnapshot> { cont ->
                    ref.get().addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            cont.resume(task.result!!)
                        } else {
                            cont.resumeWithException(task.exception ?: RuntimeException("Unknown database read error"))
                        }
                    }
                }
            }

            if (!snapshot.exists() || snapshot.value == null) {
                Result.success(WorkspaceFactory.createWorkspace())
            } else {
                val jsonElement = anyToJsonElement(snapshot.value)
                val jsonObject = jsonElement as? JsonObject ?: JsonObject(emptyMap())
                val workspace = parseWorkspaceSafely(jsonObject)
                Result.success(workspace)
            }
        } catch (e: TimeoutCancellationException) {
            Result.failure(RuntimeException(ErrorCodes.FIREBASE_NETWORK))
        } catch (e: DatabaseException) {
            if (e.message?.contains("PERMISSION_DENIED", ignoreCase = true) == true) {
                Result.failure(RuntimeException(ErrorCodes.FIREBASE_PERMISSIONS))
            } else {
                Result.failure(RuntimeException(ErrorCodes.FIREBASE_NETWORK))
            }
        } catch (e: WorkspaceValidationException) {
            Result.failure(e)
        } catch (e: Exception) {
            if (e.message?.contains("PERMISSION_DENIED", ignoreCase = true) == true) {
                Result.failure(RuntimeException(ErrorCodes.FIREBASE_PERMISSIONS))
            } else {
                Result.failure(RuntimeException(ErrorCodes.FIREBASE_NETWORK))
            }
        }
    }

    override suspend fun update(userId: String, operations: List<WorkspaceOperation>): Result<Workspace> {
        val ref = getRef(userId)
        var attempts = 0
        while (attempts < 6) {
            attempts++
            try {
                val resultWorkspace = runTransactionWithTimeout(ref, operations, 12000L)
                return Result.success(resultWorkspace)
            } catch (e: WorkspaceValidationException) {
                return Result.failure(e)
            } catch (e: TransactionAbortedException) {
                if (attempts >= 6) {
                    return Result.failure(RuntimeException(ErrorCodes.FIREBASE_CONFLICT))
                }
            } catch (e: TimeoutCancellationException) {
                return Result.failure(RuntimeException(ErrorCodes.FIREBASE_NETWORK))
            } catch (e: Exception) {
                if (e.message?.contains("PERMISSION_DENIED", ignoreCase = true) == true) {
                    return Result.failure(RuntimeException(ErrorCodes.FIREBASE_PERMISSIONS))
                }
                if (attempts >= 6) {
                    return Result.failure(RuntimeException(ErrorCodes.FIREBASE_CONFLICT))
                }
            }
        }
        return Result.failure(RuntimeException(ErrorCodes.FIREBASE_CONFLICT))
    }

    private suspend fun runTransactionWithTimeout(
        ref: DatabaseReference,
        operations: List<WorkspaceOperation>,
        timeoutMs: Long
    ): Workspace {
        return withTimeout(timeoutMs) {
            suspendCancellableCoroutine { continuation ->
                ref.runTransaction(object : Transaction.Handler {
                    override fun doTransaction(currentData: MutableData): Transaction.Result {
                        val raw = currentData.value
                        val previous = if (raw == null) {
                            WorkspaceFactory.createWorkspace()
                        } else {
                            try {
                                val jsonElement = anyToJsonElement(raw)
                                val jsonObject = jsonElement as? JsonObject ?: JsonObject(emptyMap())
                                parseWorkspaceSafely(jsonObject)
                            } catch (e: Exception) {
                                return Transaction.abort()
                            }
                        }

                        val next = try {
                            WorkspaceReducer.applyOperations(previous, operations, System.currentTimeMillis())
                        } catch (e: Exception) {
                            return Transaction.abort()
                        }

                        if (next.revision == previous.revision) {
                            return Transaction.success(currentData)
                        }

                        val encoded = WorkspaceJson.encodeToJsonElement(Workspace.serializer(), next)
                        val mapValue = jsonElementToAny(encoded)
                        currentData.value = mapValue
                        return Transaction.success(currentData)
                    }

                    override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                        if (error != null) {
                            if (error.code == DatabaseError.PERMISSION_DENIED) {
                                continuation.resumeWithException(RuntimeException(ErrorCodes.FIREBASE_PERMISSIONS))
                            } else {
                                continuation.resumeWithException(error.toException())
                            }
                        } else if (!committed) {
                            continuation.resumeWithException(TransactionAbortedException())
                        } else {
                            val raw = snapshot?.value
                            if (raw == null) {
                                continuation.resume(WorkspaceFactory.createWorkspace())
                            } else {
                                try {
                                    val jsonElement = anyToJsonElement(raw)
                                    val jsonObject = jsonElement as? JsonObject ?: JsonObject(emptyMap())
                                    val workspace = parseWorkspaceSafely(jsonObject)
                                    continuation.resume(workspace)
                                } catch (e: Exception) {
                                    continuation.resumeWithException(WorkspaceValidationException(ErrorCodes.INVALID_OPERATION))
                                }
                            }
                        }
                    }
                })
            }
        }
    }
}

class TransactionAbortedException : RuntimeException("Transaction aborted")
