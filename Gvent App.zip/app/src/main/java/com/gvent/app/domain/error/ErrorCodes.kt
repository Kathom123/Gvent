package com.gvent.app.domain.error

import com.gvent.app.domain.model.AppLanguage

object ErrorCodes {
    const val FIREBASE_NETWORK = "FIREBASE_NETWORK"
    const val FIREBASE_PERMISSIONS = "FIREBASE_PERMISSIONS"
    const val FIREBASE_CONFIGURATION = "FIREBASE_CONFIGURATION"
    const val FIREBASE_CONFLICT = "FIREBASE_CONFLICT"
    const val INVALID_OPERATION = "INVALID_OPERATION"

    fun messageFor(code: String, lang: AppLanguage): String {
        return when (code) {
            FIREBASE_NETWORK -> if (lang == AppLanguage.SPANISH) {
                "Firebase no responde. Comprueba la conexión del servidor."
            } else {
                "Firebase is not responding. Check server connection."
            }
            FIREBASE_PERMISSIONS -> if (lang == AppLanguage.SPANISH) {
                "La base de datos rechazó la operación."
            } else {
                "Database rejected the operation."
            }
            FIREBASE_CONFIGURATION -> if (lang == AppLanguage.SPANISH) {
                "Firebase no está configurado correctamente."
            } else {
                "Firebase is not configured correctly."
            }
            FIREBASE_CONFLICT -> if (lang == AppLanguage.SPANISH) {
                "Hay cambios simultáneos. Vuelve a sincronizar."
            } else {
                "Concurrent changes detected. Please re-sync."
            }
            INVALID_OPERATION -> if (lang == AppLanguage.SPANISH) {
                "Operación no válida."
            } else {
                "Invalid operation."
            }
            else -> if (lang == AppLanguage.SPANISH) {
                "Error desconocido."
            } else {
                "Unknown error."
            }
        }
    }
}
