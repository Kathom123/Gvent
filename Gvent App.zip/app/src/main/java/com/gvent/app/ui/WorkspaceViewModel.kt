package com.gvent.app.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.gvent.app.domain.ControlsPatch
import com.gvent.app.domain.Workspace
import com.gvent.app.domain.WorkspaceFactory
import com.gvent.app.domain.WorkspaceOperation
import com.gvent.app.domain.WorkspaceReducer
import com.gvent.app.domain.WorkspaceValidationException
import com.gvent.app.domain.error.ErrorCodes
import com.gvent.app.domain.model.AppLanguage
import com.gvent.app.domain.repository.AuthRepository
import com.gvent.app.domain.repository.WorkspaceRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

class WorkspaceViewModel(
    private val authRepository: AuthRepository,
    private val workspaceRepository: WorkspaceRepository,
    application: Application? = null
) : ViewModel() {

    private val _workspace = MutableStateFlow(WorkspaceFactory.createWorkspace())
    val workspace: StateFlow<Workspace> = _workspace.asStateFlow()

    private val _syncStatus = MutableStateFlow(SyncStatus.SYNCED)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()

    private val _syncError = MutableStateFlow<String?>(null)
    val syncError: StateFlow<String?> = _syncError.asStateFlow()

    private val _lastSyncAt = MutableStateFlow<Long?>(null)
    val lastSyncAt: StateFlow<Long?> = _lastSyncAt.asStateFlow()

    private val _pendingCount = MutableStateFlow(0)
    val pendingCount: StateFlow<Int> = _pendingCount.asStateFlow()

    private val _sessionExpired = MutableSharedFlow<Unit>()
    val sessionExpired: SharedFlow<Unit> = _sessionExpired.asSharedFlow()

    // Note: Pending queue is kept in memory only. If the app dies before syncing, pending changes are lost (accepted demo behavior).
    private val pendingQueue = mutableListOf<WorkspaceOperation>()
    private var flushJob: Job? = null
    private val mutex = Mutex()
    private var lastRemoteWorkspace: Workspace = WorkspaceFactory.createWorkspace()
    private var isVisible = true

    private val connectivityManager = application?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            viewModelScope.launch {
                if (pendingQueue.isNotEmpty()) {
                    flush()
                } else {
                    refresh()
                }
            }
        }
    }

    private fun currentUserId(): String? {
        return authRepository.currentUser.value?.uid ?: Firebase.auth.currentUser?.uid
    }

    init {
        try {
            if (connectivityManager != null) {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                connectivityManager.registerNetworkCallback(request, networkCallback)
            }
        } catch (e: Exception) {}

        viewModelScope.launch {
            while (true) {
                delay(5000)
                if (isVisible) {
                    if (currentUserId() == null) {
                        _sessionExpired.emit(Unit)
                        continue
                    }
                    if (pendingQueue.isNotEmpty()) {
                        flush()
                    } else {
                        refresh()
                    }
                }
            }
        }
    }

    fun setVisible(visible: Boolean) {
        isVisible = visible
        if (visible) {
            viewModelScope.launch {
                if (currentUserId() == null) {
                    _sessionExpired.emit(Unit)
                    return@launch
                }
                if (pendingQueue.isNotEmpty()) {
                    flush()
                } else {
                    refresh()
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            if (connectivityManager != null) {
                connectivityManager.unregisterNetworkCallback(networkCallback)
            }
        } catch (e: Exception) {}
    }

    private fun generateId(): String = UUID.randomUUID().toString().replace("-", "")

    fun queue(operation: WorkspaceOperation) {
        if (currentUserId() == null) {
            viewModelScope.launch { _sessionExpired.emit(Unit) }
            return
        }
        val now = System.currentTimeMillis()
        val updated = WorkspaceReducer.applyOperations(_workspace.value, listOf(operation), now)
        _workspace.value = updated
        pendingQueue.add(operation)
        _pendingCount.value = pendingQueue.size
        _syncStatus.value = SyncStatus.SAVING
        _syncError.value = null
        scheduleFlush(250)
    }

    private fun scheduleFlush(delayMs: Long) {
        flushJob?.cancel()
        flushJob = viewModelScope.launch {
            delay(delayMs)
            flush()
        }
    }

    suspend fun flush() {
        val userId = currentUserId()
        if (userId == null) {
            _sessionExpired.emit(Unit)
            return
        }
        mutex.withLock {
            if (pendingQueue.isEmpty()) return@withLock
            _syncStatus.value = SyncStatus.SAVING
            val batch = pendingQueue.take(64)
            val result = workspaceRepository.update(userId, batch)

            if (result.isSuccess) {
                val remoteWorkspace = result.getOrThrow()
                lastRemoteWorkspace = remoteWorkspace
                _workspace.value = remoteWorkspace
                repeat(batch.size) {
                    if (pendingQueue.isNotEmpty()) {
                        pendingQueue.removeAt(0)
                    }
                }
                _pendingCount.value = pendingQueue.size
                _lastSyncAt.value = System.currentTimeMillis()
                if (pendingQueue.isEmpty()) {
                    _syncStatus.value = SyncStatus.SYNCED
                } else {
                    scheduleFlush(300)
                }
            } else {
                val error = result.exceptionOrNull()
                val message = error?.message ?: ""
                if (currentUserId() == null) {
                    _sessionExpired.emit(Unit)
                    return@withLock
                }
                val isInvalidOp = error is WorkspaceValidationException ||
                    message.contains("Invalid operation", ignoreCase = true) ||
                    message.contains("Safety", ignoreCase = true) ||
                    message.contains("out of range", ignoreCase = true) ||
                    message.contains("Maximum", ignoreCase = true) ||
                    message.contains("exceed 24 hours", ignoreCase = true)

                if (isInvalidOp) {
                    pendingQueue.clear()
                    _pendingCount.value = 0
                    _workspace.value = lastRemoteWorkspace
                    _syncStatus.value = SyncStatus.ERROR
                    _syncError.value = ErrorCodes.messageFor(ErrorCodes.INVALID_OPERATION, AppLanguage.SPANISH)
                } else {
                    _syncStatus.value = SyncStatus.ERROR
                    _syncError.value = message.ifEmpty { ErrorCodes.messageFor(ErrorCodes.FIREBASE_NETWORK, AppLanguage.SPANISH) }
                    scheduleFlush(2500)
                }
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            val userId = currentUserId()
            if (userId == null) {
                _sessionExpired.emit(Unit)
                return@launch
            }
            if (pendingQueue.isNotEmpty() || _syncStatus.value == SyncStatus.SAVING) return@launch
            _syncStatus.value = SyncStatus.CONNECTING
            val result = workspaceRepository.read(userId)
            if (result.isSuccess) {
                val remote = result.getOrThrow()
                lastRemoteWorkspace = remote
                _workspace.value = remote
                _syncStatus.value = SyncStatus.SYNCED
                _lastSyncAt.value = System.currentTimeMillis()
                _syncError.value = null
            } else {
                val error = result.exceptionOrNull()
                val message = error?.message ?: ""
                if (currentUserId() == null) {
                    _sessionExpired.emit(Unit)
                    return@launch
                }
                _syncStatus.value = SyncStatus.ERROR
                _syncError.value = message.ifEmpty { ErrorCodes.messageFor(ErrorCodes.FIREBASE_NETWORK, AppLanguage.SPANISH) }
                delay(2500)
                if (isVisible && currentUserId() != null && _syncStatus.value == SyncStatus.ERROR) {
                    refresh()
                }
            }
        }
    }

    fun retry() {
        viewModelScope.launch {
            if (pendingQueue.isNotEmpty()) {
                flush()
            } else {
                refresh()
            }
        }
    }

    fun setMode(mode: String) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(mode = mode)))
    fun setSpeed(speed: Int) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(speed = speed)))
    fun setRunning(running: Boolean) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(running = running)))
    fun setTimer(timer: String) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(timer = timer)))
    fun setTimerEnd(timerEnd: Long?) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(timerEnd = timerEnd)))
    fun setWarning(warning: Int) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(warning = warning)))
    fun setDanger(danger: Int) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(danger = danger)))
    fun setAutoSafety(autoSafety: Boolean) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(autoSafety = autoSafety)))
    fun setNightMode(nightMode: Boolean) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(nightMode = nightMode)))
    fun setAlerts(alerts: Boolean) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(alerts = alerts)))
    fun setSimulated(simulated: Boolean) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(simulated = simulated)))
    fun setMuted(muted: Boolean) = queue(WorkspaceOperation.ControlsOperation(generateId(), ControlsPatch(muted = muted)))

    fun addDevice(name: String) = queue(WorkspaceOperation.AddDeviceOperation(generateId(), name))
    fun addActivity(title: String, detail: String) = queue(WorkspaceOperation.AddEventOperation(generateId(), title, detail))
}
