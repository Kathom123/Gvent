package com.gvent.app.domain

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Activity(
    val id: String,
    val title: String,
    val detail: String,
    val time: String,
    val type: ActivityType,
    val tone: ActivityTone
)

@Serializable
enum class ActivityType {
    @SerialName("shield") SHIELD,
    @SerialName("wind") WIND,
    @SerialName("bell") BELL,
    @SerialName("check") CHECK;
}

@Serializable
enum class ActivityTone {
    @SerialName("green") GREEN,
    @SerialName("blue") BLUE,
    @SerialName("amber") AMBER;
}
