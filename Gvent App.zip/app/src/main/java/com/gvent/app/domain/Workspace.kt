package com.gvent.app.domain

import kotlinx.serialization.Serializable

@Serializable
data class Workspace(
    val schemaVersion: Int = 1,
    val revision: Long,
    val updatedAt: Long,
    val controls: Controls,
    val devices: List<DemoDevice> = emptyList(),
    val events: List<Activity> = emptyList(),
    val appliedIds: List<String> = emptyList()
)
