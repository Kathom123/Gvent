package com.gvent.app.di

import android.content.Context
import com.google.firebase.FirebaseApp
import com.gvent.app.R
import com.gvent.app.data.firebase.FirebaseAuthRepository
import com.gvent.app.data.firebase.FirebaseWorkspaceRepository
import com.gvent.app.data.model.AppUser
import com.gvent.app.domain.Workspace
import com.gvent.app.domain.WorkspaceFactory
import com.gvent.app.domain.WorkspaceOperation
import com.gvent.app.domain.WorkspaceReducer
import com.gvent.app.domain.WorkspaceValidationException
import com.gvent.app.domain.repository.AuthRepository
import com.gvent.app.domain.repository.WorkspaceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object ServiceLocator {
    lateinit var authRepository: AuthRepository
    lateinit var workspaceRepository: WorkspaceRepository

    var ready: Boolean = false
        private set
    var startupError: String? = null
        private set

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        val appContext = context.applicationContext
        try {
            if (FirebaseApp.getApps(appContext).isEmpty()) {
                FirebaseApp.initializeApp(appContext)
            }
            if (FirebaseApp.getApps(appContext).isEmpty()) {
                startupError = appContext.getString(R.string.startup_firebase_missing)
                return
            }
            authRepository = FirebaseAuthRepository()
            workspaceRepository = FirebaseWorkspaceRepository()
            ready = true
        } catch (error: Throwable) {
            ready = false
            startupError = appContext.getString(
                R.string.startup_firebase_error,
                error.message ?: error.javaClass.simpleName
            )
        }
    }
}

class FakeAuthRepository : AuthRepository {
    private val _currentUser = MutableStateFlow<AppUser?>(AppUser("user-agua", "Agua", "Agua"))
    override val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    override suspend fun login(username: String, password: String): Result<AppUser> {
        val user = AppUser("user-$username", username, username.replaceFirstChar { it.uppercase() })
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun registerIfNeeded(email: String, password: String): Result<AppUser> {
        val username = email.substringBefore("@")
        val user = AppUser("user-$username", username, username.replaceFirstChar { it.uppercase() })
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun logout() {
        _currentUser.value = null
    }
}

class FakeWorkspaceRepository : WorkspaceRepository {
    var currentWorkspace: Workspace = WorkspaceFactory.createWorkspace()
    var shouldFailInvalidOperation: Boolean = false

    override suspend fun read(userId: String): Result<Workspace> {
        return Result.success(currentWorkspace)
    }

    override suspend fun update(userId: String, operations: List<WorkspaceOperation>): Result<Workspace> {
        if (shouldFailInvalidOperation) {
            return Result.failure(WorkspaceValidationException("Invalid operation."))
        }
        try {
            currentWorkspace = WorkspaceReducer.applyOperations(currentWorkspace, operations, System.currentTimeMillis())
            return Result.success(currentWorkspace)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }
}
