package com.gvent.app.domain.model

enum class AppLanguage(val code: String) {
    SPANISH("es"),
    ENGLISH("en")
}
