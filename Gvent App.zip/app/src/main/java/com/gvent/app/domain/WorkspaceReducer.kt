package com.gvent.app.domain

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object WorkspaceReducer {

    fun normalizeControls(controls: Controls, now: Long): Controls {
        var next = controls
        if (next.timerEnd != null && next.timerEnd <= now) {
            next = next.copy(
                running = false,
                timerEnd = null,
                timer = "Never"
            )
        }
        if (next.simulated && next.autoSafety && next.danger <= 612) {
            next = next.copy(
                running = true,
                speed = 100,
                mode = "Auto",
                timerEnd = null,
                timer = "Never",
                nightMode = false
            )
        }
        return next
    }

    private fun formatTime(now: Long): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date(now))
    }

    fun applyOperations(
        previous: Workspace,
        operations: List<WorkspaceOperation>,
        now: Long
    ): Workspace {
        var nextControls = previous.controls
        val nextDevices = previous.devices.toMutableList()
        val nextEvents = previous.events.toMutableList()
        val nextAppliedIds = previous.appliedIds.toMutableList()
        var changed = false

        for (operation in operations) {
            if (nextAppliedIds.contains(operation.id)) continue
            changed = true
            when (operation) {
                is WorkspaceOperation.ControlsOperation -> {
                    if (operation.patch.timerEnd != null && operation.patch.timerEnd > now + 86_400_000L) {
                        throw WorkspaceValidationException("Simulation timers cannot exceed 24 hours.")
                    }
                    if (previous.controls.simulated &&
                        previous.controls.autoSafety &&
                        previous.controls.danger <= 612 &&
                        operation.patch.autoSafety == false
                    ) {
                        throw WorkspaceValidationException("End the safety test before disabling automatic safety.")
                    }
                    nextControls = operation.patch.applyTo(nextControls)
                }
                is WorkspaceOperation.AddDeviceOperation -> {
                    if (!nextDevices.any { it.id == operation.id }) {
                        if (nextDevices.size >= 32) {
                            throw WorkspaceValidationException("Maximum of 32 demo devices.")
                        }
                        val suffix = if (operation.id.length >= 8) operation.id.takeLast(8) else operation.id
                        nextDevices.add(
                            DemoDevice(
                                id = operation.id,
                                name = operation.name,
                                model = "Demo sensor · $suffix",
                                icon = DeviceIcon.DEVICES,
                                value = "32 ppm",
                                status = "Online"
                            )
                        )
                    }
                }
                is WorkspaceOperation.AddEventOperation -> {
                    if (!nextEvents.any { it.id == operation.id }) {
                        nextEvents.add(
                            0,
                            Activity(
                                id = operation.id,
                                title = operation.title,
                                detail = operation.detail,
                                time = formatTime(now),
                                type = ActivityType.CHECK,
                                tone = ActivityTone.GREEN
                            )
                        )
                        if (nextEvents.size > 100) {
                            nextEvents.subList(100, nextEvents.size).clear()
                        }
                    }
                }
            }
            nextAppliedIds.add(operation.id)
        }

        WorkspaceValidator.validate(nextControls)
        val normalized = normalizeControls(nextControls, now)
        if (normalized != nextControls) {
            changed = true
        }
        val truncatedAppliedIds = nextAppliedIds.takeLast(256)
        val newRevision = if (changed) previous.revision + 1 else previous.revision
        val newUpdatedAt = if (changed) now else previous.updatedAt

        val result = Workspace(
            schemaVersion = 1,
            revision = newRevision,
            updatedAt = newUpdatedAt,
            controls = normalized,
            devices = nextDevices,
            events = nextEvents,
            appliedIds = truncatedAppliedIds
        )
        WorkspaceValidator.validateWorkspace(result)
        return result
    }
}
