package com.gvent.app.domain

import kotlinx.serialization.Serializable

@Serializable
data class ControlsPatch(
    val mode: String? = null,
    val speed: Int? = null,
    val running: Boolean? = null,
    val timer: String? = null,
    val timerEnd: Long? = null,
    val warning: Int? = null,
    val danger: Int? = null,
    val autoSafety: Boolean? = null,
    val nightMode: Boolean? = null,
    val alerts: Boolean? = null,
    val simulated: Boolean? = null,
    val muted: Boolean? = null
) {
    fun isEmpty(): Boolean =
        mode == null && speed == null && running == null && timer == null &&
        timerEnd == null && warning == null && danger == null && autoSafety == null &&
        nightMode == null && alerts == null && simulated == null && muted == null

    fun applyTo(controls: Controls): Controls {
        return controls.copy(
            mode = mode ?: controls.mode,
            speed = speed ?: controls.speed,
            running = running ?: controls.running,
            timer = timer ?: controls.timer,
            timerEnd = timerEnd ?: controls.timerEnd,
            warning = warning ?: controls.warning,
            danger = danger ?: controls.danger,
            autoSafety = autoSafety ?: controls.autoSafety,
            nightMode = nightMode ?: controls.nightMode,
            alerts = alerts ?: controls.alerts,
            simulated = simulated ?: controls.simulated,
            muted = muted ?: controls.muted
        )
    }
}

sealed class WorkspaceOperation {
    abstract val id: String

    @Serializable
    data class ControlsOperation(override val id: String, val patch: ControlsPatch) : WorkspaceOperation()

    @Serializable
    data class AddDeviceOperation(override val id: String, val name: String) : WorkspaceOperation()

    @Serializable
    data class AddEventOperation(override val id: String, val title: String, val detail: String) : WorkspaceOperation()
}
