package com.gvent.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

// The bundled Manrope and DM Sans files are variable fonts. Loading those
// resources through Compose crashes on several Android versions at startup.
// System sans-serif keeps the screen readable and the process alive.
val ManropeFontFamily = FontFamily.SansSerif
val DmSansFontFamily = FontFamily.SansSerif

val GventTypography = Typography(
    displayLarge = TextStyle(fontFamily = ManropeFontFamily),
    displayMedium = TextStyle(fontFamily = ManropeFontFamily),
    displaySmall = TextStyle(fontFamily = ManropeFontFamily),
    headlineLarge = TextStyle(fontFamily = ManropeFontFamily),
    headlineMedium = TextStyle(fontFamily = ManropeFontFamily, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontFamily = ManropeFontFamily),
    titleLarge = TextStyle(fontFamily = ManropeFontFamily),
    titleMedium = TextStyle(fontFamily = ManropeFontFamily),
    titleSmall = TextStyle(fontFamily = ManropeFontFamily),
    bodyLarge = TextStyle(fontFamily = DmSansFontFamily),
    bodyMedium = TextStyle(fontFamily = DmSansFontFamily),
    bodySmall = TextStyle(fontFamily = DmSansFontFamily),
    labelLarge = TextStyle(fontFamily = DmSansFontFamily),
    labelMedium = TextStyle(fontFamily = DmSansFontFamily),
    labelSmall = TextStyle(fontFamily = DmSansFontFamily)
)
