package com.gvent.app.domain

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class DemoDevice(
    val id: String,
    val name: String,
    val model: String,
    val icon: DeviceIcon,
    val value: String,
    val status: String
)

@Serializable
enum class DeviceIcon {
    @SerialName("devices") DEVICES,
    @SerialName("wind") WIND,
    @SerialName("thermometer") THERMOMETER;
}
