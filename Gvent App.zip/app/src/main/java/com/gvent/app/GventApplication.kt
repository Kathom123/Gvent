package com.gvent.app

import android.app.Application
import com.gvent.app.di.ServiceLocator

class GventApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
