package com.gvent.app.ui.login

import android.app.Application
import android.util.Patterns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuthException
import com.gvent.app.R
import com.gvent.app.di.ServiceLocator
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val username: String = "",
    val password: String = "",
    val error: String? = null,
    val pending: Boolean = false
)

class LoginViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val authRepository get() = ServiceLocator.authRepository

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    private val _loginSuccess = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val loginSuccess: SharedFlow<Unit> = _loginSuccess.asSharedFlow()

    private val usernameRegex = Regex("^[a-zA-Z0-9._-]{1,80}$")

    fun onUsernameChanged(username: String) {
        _uiState.update { it.copy(username = username, error = null) }
    }

    fun onPasswordChanged(password: String) {
        _uiState.update { it.copy(password = password, error = null) }
    }

    fun clearPassword() {
        _uiState.update { it.copy(password = "") }
    }

    fun mapUsernameToEmail(username: String): String {
        val clean = username.trim().lowercase()
        if (clean.contains("@")) {
            if (!Patterns.EMAIL_ADDRESS.matcher(clean).matches()) {
                throw IllegalArgumentException("Invalid username format")
            }
            return clean
        }
        if (!usernameRegex.matches(clean)) {
            throw IllegalArgumentException("Invalid username format")
        }
        return "$clean@gvent.app"
    }

    fun login() {
        val currentState = _uiState.value
        val trimmedUser = currentState.username.trim()
        val password = currentState.password

        if (trimmedUser.isEmpty() || password.isEmpty()) {
            _uiState.update { it.copy(error = getApplication<Application>().getString(R.string.login_invalid_credentials)) }
            return
        }

        val email: String
        try {
            email = mapUsernameToEmail(trimmedUser)
        } catch (e: Exception) {
            _uiState.update { it.copy(error = getApplication<Application>().getString(R.string.login_invalid_credentials)) }
            return
        }

        _uiState.update { it.copy(pending = true, error = null) }

        viewModelScope.launch {
            try {
                if (!ServiceLocator.ready) {
                    _uiState.update {
                        it.copy(
                            pending = false,
                            error = ServiceLocator.startupError
                                ?: getApplication<Application>().getString(R.string.startup_firebase_missing)
                        )
                    }
                    return@launch
                }

                var result = authRepository.login(email, password)
                if (result.isFailure && trimmedUser.lowercase() == "agua" && password == "agua") {
                    val regResult = authRepository.registerIfNeeded(email, password)
                    result = if (regResult.isSuccess) authRepository.login(email, password) else regResult
                }

                if (result.isSuccess) {
                    _uiState.update { it.copy(pending = false, error = null) }
                    _loginSuccess.tryEmit(Unit)
                } else {
                    _uiState.update { it.copy(pending = false, error = mapAuthError(result.exceptionOrNull())) }
                }
            } catch (e: Throwable) {
                _uiState.update { it.copy(pending = false, error = mapAuthError(e)) }
            }
        }
    }

    private fun mapAuthError(exception: Throwable?): String {
        val app = getApplication<Application>()
        val code = (exception as? FirebaseAuthException)?.errorCode.orEmpty()
        val message = exception?.message.orEmpty()
        val token = "$code $message"
        return when {
            token.contains("WEAK_PASSWORD", ignoreCase = true) ||
                token.contains("least 6", ignoreCase = true) ->
                app.getString(R.string.login_weak_password)
            token.contains("OPERATION_NOT_ALLOWED", ignoreCase = true) ->
                app.getString(R.string.login_auth_disabled)
            token.contains("INVALID_CREDENTIAL", ignoreCase = true) ||
                token.contains("USER_NOT_FOUND", ignoreCase = true) ||
                token.contains("WRONG_PASSWORD", ignoreCase = true) ||
                token.contains("INVALID_EMAIL", ignoreCase = true) ||
                token.contains("INVALID_LOGIN", ignoreCase = true) ||
                token.contains("Invalid username format", ignoreCase = true) ->
                app.getString(R.string.login_invalid_credentials)
            token.contains("TOO_MANY_REQUESTS", ignoreCase = true) ->
                app.getString(R.string.login_too_many_requests)
            token.contains("NETWORK", ignoreCase = true) ||
                token.contains("timeout", ignoreCase = true) ->
                app.getString(R.string.login_network_error)
            else -> app.getString(R.string.login_unknown_error)
        }
    }
}
