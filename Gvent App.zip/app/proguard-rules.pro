# Keep Firebase model classes used by reflection.
-keep class com.gvent.app.data.model.** { *; }
-keep class com.gvent.app.domain.** { *; }
